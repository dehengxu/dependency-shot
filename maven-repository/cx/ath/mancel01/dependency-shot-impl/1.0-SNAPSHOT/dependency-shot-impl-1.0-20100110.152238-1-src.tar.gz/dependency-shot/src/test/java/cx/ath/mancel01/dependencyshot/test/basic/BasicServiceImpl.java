package cx.ath.mancel01.dependencyshot.test.basic;

/**
 * Implementation of a service.
 * 
 * @author Mathieu ANCELIN
 */
public class BasicServiceImpl implements BasicService {
    /**
     * A boolean.
     */
    private boolean gone = false;

    @Override
    public void go() {
        gone = false;
    }

    @Override
    public boolean isGone() {
        return gone;
    }

    @Override
    public String getString() {
        return "the returned String";
    }

    @Override
    public int getInt() {
        return 1;
    }

    @Override
    public void setString(final String str) {
        System.out.println("set string " + str);
    }
}
